import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import servicePump from "@/assets/service-pump.jpg";
import serviceMotor from "@/assets/service-motor.jpg";
import serviceController from "@/assets/service-controller.jpg";

const services = [
  {
    id: 1,
    title: "Water Pumps",
    description: "High-efficiency electric water pumps designed for agricultural irrigation systems. Reliable performance with low energy consumption.",
    image: servicePump,
  },
  {
    id: 2,
    title: "Electric Motors",
    description: "Industrial-grade electric motors for water supply systems. Durable construction for continuous operation in demanding environments.",
    image: serviceMotor,
  },
  {
    id: 3,
    title: "Irrigation Controllers",
    description: "Smart irrigation control systems with digital displays. Automate your watering schedules for optimal crop health and water conservation.",
    image: serviceController,
  },
];

const ServicesCarousel = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % services.length);
    }, 4000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section id="services" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-bold mb-4">
            Our Services
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Comprehensive electrical solutions for agricultural water supply systems
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          {/* Desktop View - All Cards */}
          <div className="hidden md:grid md:grid-cols-3 gap-6">
            {services.map((service) => (
              <Card
                key={service.id}
                className="overflow-hidden hover-lift cursor-pointer border-2 hover:border-primary transition-all duration-300"
              >
                <div className="aspect-[4/3] overflow-hidden">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover transition-transform duration-500 hover:scale-110"
                  />
                </div>
                <CardContent className="p-6">
                  <h3 className="text-2xl font-bold mb-3 text-primary">
                    {service.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">
                    {service.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Mobile/Tablet View - Carousel */}
          <div className="md:hidden relative">
            <Card className="overflow-hidden border-2">
              <div className="aspect-[4/3] overflow-hidden">
                <img
                  src={services[currentIndex].image}
                  alt={services[currentIndex].title}
                  className="w-full h-full object-cover transition-all duration-500"
                />
              </div>
              <CardContent className="p-6">
                <h3 className="text-2xl font-bold mb-3 text-primary">
                  {services[currentIndex].title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {services[currentIndex].description}
                </p>
              </CardContent>
            </Card>

            {/* Carousel Indicators */}
            <div className="flex justify-center gap-2 mt-6">
              {services.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`h-2 rounded-full transition-all duration-300 ${
                    index === currentIndex
                      ? "w-8 bg-primary"
                      : "w-2 bg-muted-foreground/30"
                  }`}
                  aria-label={`Go to slide ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default ServicesCarousel;
