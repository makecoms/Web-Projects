import { Button } from "@/components/ui/button";
import heroBackground from "@/assets/hero-background.jpg";

const Hero = () => {
  const scrollToContact = () => {
    const footer = document.getElementById("contact");
    footer?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ 
          backgroundImage: `url(${heroBackground})`,
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-hero-overlay/90 via-hero-overlay/70 to-hero-overlay/50" />
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 sm:px-6 lg:px-8 py-32 text-center">
        <div className="max-w-4xl mx-auto space-y-8 animate-fade-in">
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold text-white leading-tight">
            Powering Agricultural Excellence
          </h1>
          <p className="text-xl sm:text-2xl md:text-3xl text-white/90 font-medium">
            Advanced Electrical Solutions for Modern Irrigation
          </p>
          <p className="text-lg sm:text-xl text-white/80 max-w-2xl mx-auto">
            Providing cutting-edge water pumps, electric motors, and irrigation controllers 
            to maximize your agricultural productivity
          </p>
          
          <div className="pt-4">
            <Button
              onClick={scrollToContact}
              size="lg"
              className="bg-secondary hover:bg-secondary-hover text-secondary-foreground text-lg px-8 py-6 rounded-full shadow-elevated hover-lift transition-all duration-300"
            >
              Contact Us Today
            </Button>
          </div>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-white/50 rounded-full flex items-start justify-center p-2">
          <div className="w-1.5 h-3 bg-white/50 rounded-full" />
        </div>
      </div>
    </section>
  );
};

export default Hero;
