import { Mail, MapPin, Phone } from "lucide-react";

const Footer = () => {
  return (
    <footer id="contact" className="bg-primary text-primary-foreground">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12 mb-12">
          {/* Company Info */}
          <div className="space-y-4">
            <h3 className="text-2xl font-bold mb-4">AgroTech Solutions</h3>
            <p className="text-primary-foreground/90 leading-relaxed">
              Your trusted partner in agricultural electrical solutions. 
              Providing quality water pumps, motors, and irrigation systems for modern farming.
            </p>
          </div>

          {/* Contact Information */}
          <div className="space-y-4">
            <h4 className="text-xl font-semibold mb-4">Contact Us</h4>
            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 mt-1 flex-shrink-0" />
                <p className="text-primary-foreground/90">
                  123 Agricultural Avenue,<br />
                  Green Valley, State 12345
                </p>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 flex-shrink-0" />
                <a 
                  href="tel:+1234567890" 
                  className="text-primary-foreground/90 hover:text-primary-foreground transition-colors"
                >
                  +1 (234) 567-890
                </a>
              </div>
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 flex-shrink-0" />
                <a 
                  href="mailto:info@agrotechsolutions.com" 
                  className="text-primary-foreground/90 hover:text-primary-foreground transition-colors"
                >
                  info@agrotechsolutions.com
                </a>
              </div>
            </div>
          </div>

          {/* Business Hours */}
          <div className="space-y-4">
            <h4 className="text-xl font-semibold mb-4">Business Hours</h4>
            <div className="space-y-2 text-primary-foreground/90">
              <p className="flex justify-between">
                <span className="font-medium">Monday - Friday:</span>
                <span>8:00 AM - 6:00 PM</span>
              </p>
              <p className="flex justify-between">
                <span className="font-medium">Saturday:</span>
                <span>9:00 AM - 4:00 PM</span>
              </p>
              <p className="flex justify-between">
                <span className="font-medium">Sunday:</span>
                <span>Closed</span>
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-primary-foreground/20 pt-8 text-center">
          <p className="text-primary-foreground/80">
            © {new Date().getFullYear()} AgroTech Solutions. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
